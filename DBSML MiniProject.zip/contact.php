<?php

if(isset($_POST['name'])){
    $server = "localhost";
    $username = "root";
    $password = "";

    $con = mysqli_connect($server,$username,$password);

    if(!$con){
        die("connection to this database failed due to".
        mysqli_connect_error());
    }
    //echo "Success connecting to Db";

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $info = $_POST['info'];

    $sql = "INSERT INTO `hospital_management`.`contact` (`name`, `phone`, `email`, `address`, `age`, `gender`, `info`, `date`) VALUES ('$name', '$phone', '$email ', '$address', '$age','$gender', '$info', current_timestamp());";

    //echo $sql;

    if($con->query($sql) == true){
        echo "Successfully Inserted";
    }
    else{
        echo "ERROR : .$sql <br> $con->error";
    }

    $con->close();
}
?>