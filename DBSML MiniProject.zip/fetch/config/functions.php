<?php 

  require_once 'db.php';

  function dispaly_data(){
    global $con;
    $query1 = "select * from book";
    $result1 = mysqli_query($con,$query1);
    // $query2 = "select * from users where user_type='user'";
    // $result2 = mysqli_query($con,$query2);
    return $result1;
  }

  function dispaly_data2(){
    global $con;
    // $query1 = "select * from book";
    // $result1 = mysqli_query($con,$query1);
    $query2 = "select * from users where user_type='user'";
    $result2 = mysqli_query($con,$query2);
    return $result2;
  }

?>