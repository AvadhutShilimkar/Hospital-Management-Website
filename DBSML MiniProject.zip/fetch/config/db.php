<?php 

  $con = mysqli_connect("localhost","root","","hospital_management");

  if(!$con){
    die("Connection Error");
  }

?>