<?php

if(isset($_POST['name'])){
    $server = "localhost";
    $username = "root";
    $password = "";

    $con = mysqli_connect($server,$username,$password);

    if(!$con){
        die("connection to this database failed due to".
        mysqli_connect_error());
    }
    //echo "Success connecting to Db";

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $date = $_POST['date'];

    $sql = "INSERT INTO `hospital_management`.`book` (`name`, `phone`, `email`, `age`, `gender`, `date`, `cur_date`) VALUES ('$name', '$phone', '$email ', '$age','$gender', '$date', current_timestamp());";

    //echo $sql;

    if($con->query($sql) == true){
        echo "Thanks For booking Appointment!! Successfully Inserted";
    }
    else{
        echo "ERROR : .$sql <br> $con->error";
    }

    $con->close();
}
?>